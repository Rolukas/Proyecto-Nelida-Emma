#ifndef PERSONA_H
#define PERSONA_H

class Persona{
	
	protected:
	char asiento;
    int sala;
    
    public:
	void Capturar(char ,int);
	
};
#endif
