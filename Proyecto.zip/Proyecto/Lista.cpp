
#ifndef LISTA_H
#define LISTA_H
#include "Persona.h"

#include <iostream>
#include <sstream>
#include <fstream>
#include <iostream>
#include <string.h>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

typedef struct Nodos//nodo
{
    //INFO PELI
    int ID;
    string pelicula;
    int sala;
    char asiento;
    //FECHA
    int dia;
    int mes;
    int anio;
    
    struct Nodos *next;//siguiente
} Nodos;


//CLASE PARA CREAR LISTA
class Lista:public Persona{
	private:
    Nodos * lista;//Estructura Nodo
    
    public:
    Lista(){      //Constructor
	lista = NULL;
	}



//CLASE PARA AGREGAR NUEVA PELÍCULA
public:void agregarNodo(int ID, string pelicula, char asiento, int sala, int dia, int mes, int anio){
	
        Nodos *NuevoNodo = (Nodos *)malloc(sizeof(Nodos));
        NuevoNodo-> ID = ID;
        NuevoNodo-> pelicula = pelicula;
        NuevoNodo-> asiento = asiento;
        NuevoNodo-> dia = dia;
        NuevoNodo-> mes = mes;
        NuevoNodo-> anio= anio;
        NuevoNodo->next = NULL;
        
        if (lista == NULL){
            lista = NuevoNodo;
		}
        else{
            Nodos *aux = lista;
            while (aux->next != NULL){
                aux = aux-> next;
            }
            aux->next = NuevoNodo;
        }
    }//final agregar
    
    //MOSTAR
public:void mostrarValores(){
        Nodos *aux = lista;
        if (lista == NULL){
			system("clear");
            cout << "--- No hay películas ---" << endl;
            system("read var");
		}
        else{
			system("clear");
			cout << "LISTA: " << endl;
            while (aux != NULL){
				cout << endl;
                cout << "Nombre de la película: " << aux->pelicula << endl;
                //cout << "Asiento: " << aux->asiento << endl;
                if(aux->ID == 1){
                cout << "Tipo: Normal" << endl;
				}
				else if(aux->ID == 2){
                cout << "Tipo: Matiné" << endl;
				}
				else{
                cout << "Tipo: Preventa" << endl;
				}
                cout << "Fecha de la película: " << aux->dia << "/" << aux->mes << "/" << aux->anio << endl;
				cout << endl;
                aux = aux->next;
            }
            system("read var");
        }
    }//final mostrar
    
    
    //ELIMINAR
	public:void eliminarNodo(string _pelicula){
		Nodos *aux = lista, *ant = NULL;
        while ((aux != NULL) && (aux->pelicula != _pelicula))
        {
            ant = aux;
            aux = aux->next;
        }
        if (aux != NULL)
        {
            if (ant != NULL)
                ant->next = NULL;
            else
                lista = aux->next;
            system("clear");
            cout << "---Película Borrada---" << endl;
            system("read var");
            free(aux);
        }
        else
            cout << "Película inexistente" << endl;
    }//final eliminar
    
    
    //MODIFICAR
    public:void insertarNodoOrd(string pelicula, char asiento, int sala, int dia, int mes, int anio){
        Nodos *NuevoNodo = (Nodos *)malloc(sizeof(Nodos));
        NuevoNodo-> asiento = asiento;
        NuevoNodo-> sala = sala;
        NuevoNodo-> dia = dia;
        NuevoNodo-> mes = mes;
        NuevoNodo-> anio= anio;
        NuevoNodo->	next = NULL;
        Nodos *aux = lista;
        Nodos *ant = NULL;
        while ((aux != NULL) && (aux->pelicula < NuevoNodo->pelicula)){
            ant = aux;
            aux = aux->next;
        }
        if (ant != NULL){
            ant->next = NuevoNodo;
            NuevoNodo->next = aux;
        }
        else{
            lista = NuevoNodo;
            NuevoNodo->next = aux;
        }
    }//final modificar
	
	
	
	//Comprar Boleto
	public: Nodos *ComprarBoleto(string pelicula){
		Nodos *aux = lista;
		while ((aux != NULL) && (aux->pelicula != pelicula))
        {
            aux = aux->next;
        }
        if (aux != NULL)
        {
			return aux;
		}
		else {
			return NULL;
		}	
	}
	
};//final clase lista
#endif
