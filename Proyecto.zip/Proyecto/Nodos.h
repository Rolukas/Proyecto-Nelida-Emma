#ifndef NODOS_H
#define NODOS_H
#include <iostream>
#include <sstream>
#include <fstream>
#include <iostream>
#include <string.h>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
typedef struct Nodos//nodo
{
    //INFO PELI
    int ID;
    string pelicula;
    int sala;
    char asiento;
    //FECHA
    int dia;
    int mes;
    int anio;
    
    struct Nodos *next;//siguiente
} Nodos;
#endif
