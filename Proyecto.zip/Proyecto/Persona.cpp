#include "Persona.h"

void Persona::Capturar(char asiento, int sala){
	
	asiento = asiento;
	sala = sala;
	
}
